use UserDB

select * from UserData


-- select can be used for operation or display things in table format
-- select can be used for conditional statement (where)

-- Operations : (=, >, <, >=, <=, <> (is not equal to))

select 2*5 -- 10
select 2/5*3-9+100-200 -- -109

select * from UserData where id <= 2 -- Displays if id is lower than equal to 2

select * from UserData where id <> 1 -- Skips if id is 1


-- String functions
-- len = calculate the number of strings
select first_name 'First Name', last_name 'Last Name', len(first_name + last_name) 'Total Character' from UserData

-- uppercase, lowercase. Self explanatory
select UPPER(first_name) 'UpperCase First Name', LOWER(last_name) 'LowerCase Last Name' from UserData

-- left, right (select from index)
select first_name, left(first_name, 3), right(last_name, 5) from UserData
select left(right(left(right('Aditya Eka Wijaya', 10), 9), 8), 7) -- 'Ka Wija'

-- substring, get specific string starting from index and the length
select SUBSTRING('Thomas Euriko Siregar', 8, 6); -- 'Euriko'

-- replace, replace specific string pattern
select replace('abcdefg', 'a', 'z')

-- stuff, like replace + substring. Basically replace a specific substring
select stuff(phonenumber, 1, 1, '+62') from UserData

-- charindex, get the index of an expression
select left(email, charindex('@', email) - 1) from UserData -- prints before @email

-- Date Functions

-- GetDate, get current date
select getdate() -- Prints the current date

-- dateAdd, adds a date
select dateAdd(month, 3, getdate()) -- Current date + 3 months

-- datediff, compare different date with specific date part (eg. month, year, day)
select datediff(month, getDate(), dateAdd(month, 3, getdate())) 'Months Different' -- Should be 3 because comparing current date with the + 3 months

-- datepart

-- month of the year
select DATEPART(MONTH, getDate()) 'Current Month' -- Prints the current month


