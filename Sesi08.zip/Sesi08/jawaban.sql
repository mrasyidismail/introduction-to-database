-- Latihan SOAL SESI 9


-- NO. 1
select FishermanID, FishermanName from MsFisherman where FishermanID in ('FS001', 'FS003', 'FS011');

-- NO. 2
select FishName, FishPrice from MsFish MF, MsFishType MFT where MFT.FishTypeID = MF.FishTypeID and FishTypeName not in ('Marlin', 'Grouper', 'Bass');

-- NO. 3
select CustomerName, CustomerEmail from MsCustomer where CustomerGender = 'Male' and CustomerID not in (select CustomerID from TransactionHeader);

-- NO. 4
select FishTypeName, FishName, FishPrice from MsFishType MFT, MsFish MF, TransactionDetail TD, TransactionHeader TH, MsCustomer MC where MC.CustomerID = TH.CustomerID and TH.TransactionID = TD.TransactionID and TD.FishID = MF.FishID and MF.FishTypeID = MFT.FishTypeID and CustomerGender = 'Female' and TransactionDate in (select TransactionDate from TransactionDetail where YEAR(TransactionDate) = '2020' and datename(quarter, TransactionDate) = '2');