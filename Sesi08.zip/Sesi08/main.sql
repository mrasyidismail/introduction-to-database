create database Sesi08

use Sesi08

select * from CustomerTable CT, EmployeeTable ET where CT.employee_id = ET.employee_id and salary < 5000 order by customer_id, salary

select full_name, department from EmployeeTable where department in ('Sales', 'IT')

-- SUBQUERY
-- IN
-- Display Employee which spends more than 5000 on CustomerTable
select employee_id, full_name from EmployeeTable where employee_id in (select employee_id from CustomerTable where spendings > 5000)

-- EXIST
select * from EmployeeTable ET where exists(select * from CustomerTable where product_category = 'electronics')

-- ANY, returns true if one condition is true
select * from EmployeeTable where salary > any (select spendings from CustomerTable where salary > spendings)

-- ALL, returns true if all condition is true/false
select * from EmployeeTable where salary > ALL(select spendings from CustomerTable)

select min(spendings) from CustomerTable
select min(spendings) from CustomerTable

-- ALIAS SUBQUERY
select customer_id, full_name, department, salary from EmployeeTable ET, CustomerTable CT, (select Average = avg(spendings) from CustomerTable) as AL
where ET.employee_id = CT.employee_id and salary > AL.Average order by salary asc